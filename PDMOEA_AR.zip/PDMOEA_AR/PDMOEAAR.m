classdef PDMOEAAR < ALGORITHM
    % <many> <real/binary/permutation> <constrained/none>
    % Priority rank based evolutionary algorithm   
    %%------------------------------- Reference --------------------------------
    % V. Palakonda and R. Mallipeddi, "Pareto Dominance-Based Algorithms With Ranking Methods for 
    % Many-Objective Optimization," in IEEE Access, vol. 5, pp.
    % 11043-11053, 2017.
    %--------------------------------------------------------------------------
    
    methods
        function main(Algorithm,Problem)            
            %% Generate random population
            Population        = Problem.Initialization();
            [FrontNo,NoF]     = NDSort(Population.objs,inf);
            [~,PRANK]         = SPRANK(Population.objs,FrontNo,NoF);
            %% Optimization
            while Algorithm.NotTerminated(Population)
                MatingPool           = TournamentSelection(2,Problem.N,FrontNo,PRANK);
                Offspring            = OperatorGA(Population(MatingPool));
                Population           = [Population,Offspring];
                [FrontNo,MaxFNo]     = NDSort(Population.objs,Problem.N);
                [SRANK,PRANK]        = SPRANK(Population.objs,FrontNo,MaxFNo);           
                [null,Rank]          = sortrows([FrontNo',PRANK,SRANK]);                
                Next                 = Rank(1:Problem.N);                
                Population       = Population(Next);         	% next population
                FrontNo          = FrontNo(Next);              % the front number of each solution in the next population
                PRANK            = PRANK(Next);
            end
        end
    end
end